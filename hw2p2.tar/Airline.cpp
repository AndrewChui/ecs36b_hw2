// Name: Kwok Chui
// Student ID: 923 216 256
#include <iostream>
#include "Airline.h"
#include "Airplane.h"
using namespace std;

Airline::Airline(int nA321, int nB777, int nB787) : nAirplanes{nA321 + nB777 + nB787}
{ // have to
    // dynamically allocate an array of pointers to Airplane objects
    // and initiate them with correct capacities
    // A321 -> 10
    // B777 -> 32
    // B787 -> 40

    // an array of pointers so double stars
    // Airplane** airplaneList = (Airplane**)new(nAirplanes*sizeof(Airplane*));
    airplaneList = new Airplane *[nAirplanes];

    // initialize them with correct capacities, they should appear in increasing size
    // A321 first because it is smallest
    for (int i = 0; i < nA321; i++)
    {
        airplaneList[i] = new Airplane(10);
        // print out the maximum load
        cout << "Airplane " << (i + 1) << " maximum load 10" << endl;
    }

    // B777 next because it is second smallest
    for (int i = nA321; i < nA321 + nB777; i++)
    { // we don't want to overwrite from index 0, the bound is also shifted
        airplaneList[i] = new Airplane(32);
        // print out the maximum load
        cout << "Airplane " << (i + 1) << " maximum load 32" << endl;
    }

    // B787 last because it is largest
    for (int i = (nA321 + nB777); i < nAirplanes; i++)
    {
        airplaneList[i] = new Airplane(40);
        // print out the maximum load
        cout << "Airplane " << (i + 1) << " maximum load 40" << endl;
    }
}
void Airline::addShipment(int size)
{
    // 1. always starts from the first airplane:
    // 2. if the airplane has enough capacity(size < (maxLoad - currentLoad)), add the containers to that plane; update the currentLoad of that plane: currentLoad + size
    // 3. If the airplane does not have enough capacity, move through the list until a plane has enough capacity. update accordingly

    // exception handling: negative value
    if (size < 0)
    {
        cout << "Invalid shipment size: must be positive (skipped)" << endl;
        return;
    }
    // the loop
    // loop through all airplane until we found the first one that can fit

    for (int i = 0; i < nAirplanes; i++)
    {
        // if((airplaneList[i]->maxLoad() - airplaneList[i]->currentLoad()) >= size){
        if ((airplaneList[i]->addContainers(size)))
        {
            cout << size << " containers added to airplane " << (i + 1) << endl; // i + 1 because index 0 is airplane 1, index 1 is airplane 2
            // go back to assign.cpp where this function was called
            return;
        }
        //}
    }
    cout << " could not fit " << size << " containers" << endl;
}

void Airline::printSummary(void) const
{
    // print the summary of all airplanes that currently have shipments
    // empty airplanes are not printed
    // shows current load vs max capacity

    cout << "Summary:" << endl;
    // go through the planes
    for (int i = 0; i < nAirplanes; i++)
    {
        // if the current load of the airplane is > 0, than we print the summary for the airplane
        if ((airplaneList[i]->currentLoad()) > 0)
        {
            // print the summary
            cout << "airplane " << (i + 1) << " " << airplaneList[i]->currentLoad() << "/" << airplaneList[i]->maxLoad() << endl;
        }
    }
}

// define the destructor
Airline::~Airline(void)
{
    // first delete the elements
    for (int i = 0; i < nAirplanes; i++)
    {
        cout << "deallocating airplane " << (i + 1) << endl;
        delete airplaneList[i];
    }
    // then delete the array
    delete[] airplaneList;
}
