// Name: Kwok Chui
// Student ID: 923 216 256
#include <iostream>
#include "Airplane.h"
using namespace std;

// constructor that takes maxCapacity int for that airplane
// the parameters in the initializer list must match the data members
Airplane::Airplane(int n) : maxContainers{n}, numContainers{0} {};

// accessor member functions
// maxLoad: returns the plane's maximum capacity
// int Airplane::maxLoad(void) const
int Airplane::maxLoad(void) const
{
    return maxContainers;
}

// currentLoad: returns how many containers are currently on board
int Airplane::currentLoad(void) const
{
    return numContainers;
}

// addContainers: adds containers to the airplane and modifies the load accordingly
// true if successful and false otherwise
bool Airplane::addContainers(int n)
{
    // if there's enough remaining capacity to fit n more containers
    // increase numContainers by n
    if ((numContainers + n) <= maxLoad())
    {
        numContainers += n;
        return true;
    }
    // if there isn't enough capacity, numContainers remain the same
    else
    {
        return false;
    }
}